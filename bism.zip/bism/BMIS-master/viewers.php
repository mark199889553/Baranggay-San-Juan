<!DOCTYPE html>
<html style="background: url(Picture/bg1.jpg); background-repeat: no-repeat; background-size:cover;">
<head>
	<title>Viewers</title>
	
<link rel="stylesheet" type="text/css" href="Css/homepage.css">
<link rel="shortcut icon" href="Icon/sj.jpg">
<style type="text/css">
	.nav {
  background-color:#2e4a62;
  border: none;
  width: 100%;
  position:fixed;
  overflow: hidden;
  top: 0;
  left: 0;
  text-transform: uppercase;
  font-family: calibri;
}
</style>
<div class="nav">
	<a href="viewers.php">home</a>
	<a href="about.php">about</a>
<a href="Communication/viewersresident.php">Announcement</a>
  <a href="pendingres.php">Send Resident Info</a> 
</div>
</head>
<body>
   
</body>
</html>